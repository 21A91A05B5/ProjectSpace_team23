// const mongoose = require('mongoose');
// const stallsInfo = new mongoose.Schema({
//     name:{
//         type:String,
//         required: true
//     },
//     stallArea:{
//         type:String,
//         required: true
//     },
//     stallType:{
//         type:String,
//         required: true
//     },
//     mobileNumber:{
//         type:Number,
//         required: true
//     },
//     rentPerMonth:{
//         type:Number,
//         required:true
//     },
//     agreement:{
//         type:String,
//         // required:true
//     }
//     // date: {
//     //     type: String,
//     //     default: function() {
//     //         const now = new Date();
//     //         const year = now.getFullYear();
//     //         const month = String(now.getMonth() + 1).padStart(2, '0');
//     //         const day = String(now.getDate()).padStart(2, '0');
//     //         return `${day}-${month}-${year}`;
//     //     },
//     //     required: true // Marking the date as required
//     // },
//     // current_date: {
//     //     type: String,
//     //     default: function() {
//     //         const now = new Date();
//     //         const year = now.getFullYear();
//     //         const month = String(now.getMonth() + 1).padStart(2, '0');
//     //         const day = String(now.getDate()).padStart(2, '0');
//     //         return `${year}-${month}-${day}`;
//     //     },
//     //     required: true // Marking the date as required
//     // },
//     // time: {
//     //     type: String,
//     //     default: function() {
//     //         const now = new Date();
//     //         return `${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`;
//     //     }
//     // }
// });


//  module.exports = mongoose.model("admin", stallsInfo);


