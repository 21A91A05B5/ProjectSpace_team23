const shopsInfo = require("../../models/shopsInfo.js");
const fs = require("fs");


const addShopsInfo = async (req, res) => {
  // console.log("testing")
  // console.log(req.body);
  const agreement=(req.file)? req.file.filename:null
  const { name, shopArea, shopType, mobileNumber,rentPerMonth} = req.body
  const shopData = await shopsInfo({
      
      name,
      shopArea,
      shopType,
      mobileNumber,
      rentPerMonth,
      agreement,
      

  });
    try {
        let shopdata = shopData.save();
        res.status(200).json({ message: "Data Received", shopdata });
    } catch (error) {
        res.status(500).json({ message: "Data not Received" });
    }
  }

    //Get All users data
    const getShopsInfo = async (req, res) => {
        let result;
        try{
            result = await shopsInfo.find();
            console.log(result);
            return res.send(result);
        }catch(err){
            return console.log(err)
        }
        if(!shopsInfo){
            return res.status(400).json({message:"No Users Found."})
        }
        return res.status(201).json({shopsInfo})
        
      }

      //Stalls_Info
    
      exports.addShopsInfo = addShopsInfo;
      exports.getShopsInfo = getShopsInfo;

      
