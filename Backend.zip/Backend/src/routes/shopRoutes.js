const express = require('express');
const router = express.Router();
const multer = require('multer');
const shopInfocontrollers = require('../controllers/shopInfocontrollers.js');

const storage = multer.diskStorage({
    destination: function (req, file, callback) {
      callback(null, 'public/images')
    },
    filename: function (req, file, callback) {
      // const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      callback(null, Date.now()+"_"+file.originalname)
    }
  })
  const upload = multer({ storage: storage })





router.post("/api/add-shops-data",upload.single("agreement"),shopInfocontrollers.addShopsInfo);
router.get("/api/get-shops-data", shopInfocontrollers.getShopsInfo);


// router.get("/api/get-single-user-shops-data/:id",shopInfocontrollers.getShopsSingleDataById)
// router.put("/api/update-shops-data/:id", shopsinfocontrollers.updateShopsInfo);
// router.delete("/api/delete-shops-data/:id",shopsinfocontrollers.deleteShopsInfo);


module.exports = router;